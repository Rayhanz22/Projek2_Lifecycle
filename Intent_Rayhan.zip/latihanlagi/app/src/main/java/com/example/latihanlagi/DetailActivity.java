package com.example.latihanlagi;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast; // Tambahkan ini untuk menggunakan Toast

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private EditText editText;
    private Button button_keluar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        editText = findViewById(R.id.editText);
        button_keluar = findViewById(R.id.button_keluar);

        button_keluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String lokasi = editText.getText().toString().trim(); // Trim untuk menghapus spasi berlebih
                if (lokasi.isEmpty()) {
                    // Jika input kosong, tampilkan peringatan menggunakan Toast
                    Toast.makeText(DetailActivity.this, "Harap masukkan lokasi yang valid !", Toast.LENGTH_SHORT).show();
                } else {
                    // Jika input tidak kosong, panggil metode untuk menampilkan lokasi
                    DisplayLokasi(lokasi);
                }
            }
        });
    }

    private void DisplayLokasi(String lokasi) {
        try {
            Uri uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + lokasi);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.google.android.apps.maps");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.maps");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }
}
