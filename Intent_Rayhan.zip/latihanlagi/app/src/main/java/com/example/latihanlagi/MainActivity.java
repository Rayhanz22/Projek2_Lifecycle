package com.example.latihanlagi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi tombol
        Button btnMove = findViewById(R.id.btnMove);
        Button btnShare = findViewById(R.id.btnShare);

        // Set OnClickListener untuk btnMove
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perintah Intent Explicit untuk pindah ke halaman DetailActivity
                startActivity(new Intent(MainActivity.this, DetailActivity.class));
            }
        });

        // Set OnClickListener untuk btnShare
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perintah Intent Implicit untuk berbagi ke media sosial
                Intent intent = new Intent(Intent.ACTION_SEND);

                // Membawa data / pesan yang ingin dibagikan
                intent.putExtra(Intent.EXTRA_TEXT, "Hallo, saya berhasil menyelesaikan projek saya. Apakah kamu ingin mencoba aplikasi yang saya kembangkan?");
                intent.setType("text/plain");

                // Menjalankan perintah Intent Implicit dengan memilih aplikasi yang mendukung
                startActivity(Intent.createChooser(intent, "Bagikan ke:"));
            }
        });
    }
}
